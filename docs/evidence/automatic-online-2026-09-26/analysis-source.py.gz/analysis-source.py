import collections, hashlib, json, statistics
from pathlib import Path

root = Path('temp/requirement-automatic-2026-09-26-r3')
r = json.loads((root / 'report.json').read_text())
plan = json.loads((root / 'plan.json').read_text())
priorroot = Path(r['priorMatrix']['path']).parent
oracles = {o['caseId']: o for o in json.loads(Path('eval/fixtures/requirement-automatic-v1/oracles.json').read_text())}
cases = {c['id']: c for c in json.loads(Path('eval/fixtures/requirement-automatic-v1/cases.json').read_text())}

def dist(values):
	return {'median': statistics.median(values), 'min': min(values), 'max': max(values)} if values else None

analyses = []
for row in r['results']:
	file = root / (row['id'] + '.json')
	if not file.exists(): file = priorroot / file.name
	d = json.loads(file.read_text()); result = d['result']; calls = d['calls']
	checks = [c for point in result['checkpoints'] for c in point['checks']]
	unknown_fields = sorted({c['id'].split(':')[1] for c in checks if c['status'] == 'needs_review' and c['id'].startswith('field:')})
	unknown_values = [dict(checkpoint=point['capture']['id'], **c) for point in result['checkpoints'] for c in point['checks'] if c['status'] == 'needs_review' and c['id'].endswith(':value')]
	failed = [dict(checkpoint=point['capture']['id'], **c) for point in result['checkpoints'] for c in point['checks'] if c['status'] == 'failed']
	model_errors = [dict(purpose=c['purpose'], error=c.get('error'), status=c['status'], reservationUsd=c['reservationUsd']) for c in calls if c['status'] != 'completed']
	stages = [{'checkpoint': p['capture']['id'], 'stageStatus': p['capture']['state']['stageStatus'], 'evaluationPassed': p['capture'].get('evaluation', {}).get('passed'), 'reviewStatus': p['capture'].get('evaluation', {}).get('evidenceReview', {}).get('status'), 'reviewFailure': p['capture'].get('evaluation', {}).get('evidenceReview', {}).get('failure')} for p in result['checkpoints']]
	analyses.append({**row, 'title': cases[row['caseId']]['title'], 'plannedCheckpoints': len(oracles[row['caseId']]['checkpoints']), 'unreachedCheckpoints': len(oracles[row['caseId']]['checkpoints']) - len(result['checkpoints']), 'checks': dict(collections.Counter(c['status'] for c in checks)), 'unknownFields': unknown_fields, 'unknownValues': unknown_values, 'failedDetails': failed, 'modelErrors': model_errors, 'stages': stages, 'passedWithoutUnresolvedCalls': row['verdict'] == 'passed' and not model_errors, 'sourceSha256': hashlib.sha256(file.read_bytes()).hexdigest()})

groups = []
for s in r['summary']:
	a = [x for x in analyses if x['model'] + '/' + x['arm'] == s['group']]
	groups.append({**s, 'plannedCheckpoints': sum(len(oracles[p['caseId']]['checkpoints']) for p in plan['attempts'] if p['model'] + '/' + p['arm'] == s['group']), 'reachedCheckpoints': sum(x['checkpoints'] for x in a), 'passedWithoutUnresolvedCalls': sum(x['passedWithoutUnresolvedCalls'] for x in a), 'modelCalls': sum(x['modelCalls'] for x in a), 'countCalls': sum(x['countCalls'] for x in a), 'toolCalls': sum(x['toolCalls'] for x in a), 'toolFailures': sum(x['toolFailures'] for x in a), 'toolStatuses': {k: sum(x['toolStatuses'].get(k, 0) for x in a) for k in ['succeeded', 'failed', 'denied', 'unknown']}, 'usage': {k: sum(x['usage'].get(k, 0) for x in a) for k in ['inputTokens', 'cachedInputTokens', 'outputTokens', 'reasoningOutputTokens']}, 'reservedUsd': sum(x['reservedUsd'] for x in a), 'allThreePassedCases': sum(x['allThreePassed'] for x in s['cases']), 'unknownFieldAttempts': dict(collections.Counter(f for x in a for f in x['unknownFields'])), 'modelErrors': dict(collections.Counter(str(e['error']) for x in a for e in x['modelErrors'])), 'modelErrorPurposes': dict(collections.Counter(e['purpose'] for x in a for e in x['modelErrors'])), 'toolFailureCodes': dict(collections.Counter(code for x in a for code in x['toolFailureCodes'])), 'executionErrors': dict(collections.Counter(x['error'] for x in a if x['error'])), 'failedCheckIds': dict(collections.Counter(c['id'] for x in a for c in x['failedDetails']))})
output = {'protocol': 'automatic-matrix-analysis.v1', 'status': r['status'], 'matrixReportSha256': hashlib.sha256((root / 'report.json').read_bytes()).hexdigest(), 'priorReportSha256': r['priorMatrix']['sha256'], 'usdLimit': r['usdLimit'], 'reservedUsd': r['reservedUsd'], 'knownUsageUsd': sum(a['knownUsageUsd'] for a in analyses), 'unknownCalls': sum(a['unresolvedCalls'] for a in analyses), 'semanticQuality': 'NOT_EVALUATED', 'notes': ['Descriptive analysis only; frozen verdicts are unchanged.', 'Unknown fields are deduplicated per attempt; value and unit checks may describe the same representation mismatch.', 'business_approval expected=true actual=false means not eligible; it is not an unauthorized approval.', 'passedWithoutUnresolvedCalls is a supplementary descriptive metric, not a new primary score or proof that every workflow review completed.', 'reasoningOutputTokens defaults to zero when the compatibility response omits a breakdown; zero does not establish that reasoning was disabled.'], 'groups': groups, 'attempts': analyses}
Path('temp/automatic-analysis.json').write_text(json.dumps(output, ensure_ascii=False, indent='\t') + '\n')
print(json.dumps({'recorded': len(analyses), 'groups': [{k: g[k] for k in ['group', 'passed', 'failed', 'needsReview', 'reachedCheckpoints', 'unknownFieldAttempts', 'modelErrors']} for g in groups]}, ensure_ascii=False))
