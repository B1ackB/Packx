from pathlib import Path
import json, re, collections, hashlib

root = Path('temp/pending-change-online-2026-09-26-r3')
r = json.loads((root / 'report.json').read_text())
roots = [root]; link = r
while link.get('priorMatrix'):
	past = Path(link['priorMatrix']['path']); roots.append(past.parent); link = json.loads(past.read_text())
counts = collections.Counter(); attempts = []
pattern = r'context-(.+)-i\d+(?:-retry\d+)?$'
for a in r['results']:
	p = next(base / (a['id'] + '.json') for base in roots if (base / (a['id'] + '.json')).exists())
	d = json.loads(p.read_text()); observed = set(); success_metadata = set(); trace = {}; execution = None; requested = collections.Counter()
	for c in d['calls']:
		m = re.match(pattern, c['request'].get('callContext', {}).get('callId', ''))
		if not m: continue
		ex = m[1]
		for t in (c.get('response') or {}).get('toolCalls', []): requested[(ex, t['id'])] += 1
		for msg in c['request']['messages']:
			if msg['role'] == 'tool' and msg.get('toolCallId'):
				key = (ex, msg['toolCallId']); observed.add(key)
				if isinstance(msg.get('sourceTool'), dict) and msg['sourceTool'].get('name'): success_metadata.add(key)
	for e in d['result']['traceEvents']:
		if e['type'] == 'session.started': execution = None
		if e['type'] == 'context.snapshot.saved':
			m = re.match(pattern, e['snapshotId'])
			if m: execution = m[1]
		if e['type'] == 'tool.completed': trace[(execution, e['toolCallId'])] = e['status']
	duplicate = [dict(executionId=k[0], toolCallId=k[1], count=n) for k,n in requested.items() if n>1]
	assert not duplicate, 'Repeated call identities need a different reconciliation key.'
	missing = observed - trace.keys()
	unobserved = requested.keys() - observed - trace.keys()
	recovered = missing & success_metadata
	values = {'statusRecoveredFromHostMetadata': len(recovered), 'statusUnrecorded': len(missing - recovered), 'observedCompleted': len(observed | trace.keys()), 'traceSucceeded': sum(v=='succeeded' for v in trace.values()), 'reconciledSucceeded': sum(v=='succeeded' for v in trace.values()) + len(recovered), 'requested': len(requested), 'traceCompleted': len(trace), 'resultIncludedInModelRequest': len(observed), 'resultWithoutTrace': len(missing), 'requestWithoutCompletionEvidence': len(unobserved)}
	for k,v in values.items(): counts[(a['model'] + '/' + a['arm'], k)] += v
	attempts.append({'id': a['id'], 'sourceSha256': hashlib.sha256(p.read_bytes()).hexdigest(), **values, 'missingTrace': sorted(missing), 'unobservedRequests': sorted(unobserved)})
output = {'protocol': 'observed-tool-trace-reconciliation.v1', 'reportSha256': hashlib.sha256((root / 'report.json').read_bytes()).hexdigest(), 'method': 'Match recorded model tool-call requests and tool-role messages against final Trace events by Host execution ID and toolCallId. Assert no repeated IDs inside an execution. Does not infer completion where evidence is missing.', 'statusRecoveryRule': 'The frozen Agent Loop attaches sourceTool to a tool-role message only when a tool has validateContextResult and execution status is succeeded. Only such Host metadata can recover a missing success status; no inference from tool text. Duration remains unknown. Original traces are unchanged.', 'loopHashes': {'candidate': hashlib.sha256(Path('temp/automatic-pending-change-repair/src/agent/loop.ts').read_bytes()).hexdigest()}, 'limitations': 'This checks observed messages and terminal traces; it does not establish completeness for arbitrary unrecorded crash windows or confirm that the remote provider received a saved request. Earlier archives called this request-inclusion count resultSeenByProvider; that name is not remote receipt evidence.', 'groups': [{'group':g, **{k:v for (group,k),v in counts.items() if group==g}} for g in dict.fromkeys(g for g,k in counts)], 'attempts': attempts}
Path('temp/repair-tool-reconciliation.json').write_text(json.dumps(output,ensure_ascii=False,indent='\t') + '\n')
print(json.dumps(output['groups']))
