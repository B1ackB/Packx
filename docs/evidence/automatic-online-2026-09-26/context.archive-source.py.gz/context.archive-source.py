import gzip, hashlib, json, tarfile
from pathlib import Path

out = Path('docs/evidence/automatic-online-2026-09-26')
plan_file = Path('temp/context-continuous-2026-09-26-r5.plan.json')
report_file = Path('temp/context-continuous-2026-09-26-r5.report.json')
sha = lambda body: hashlib.sha256(body).hexdigest()
plan, report = [json.loads(p.read_text()) for p in [plan_file, report_file]]
assert report['status'] != 'running'
assert sha(plan_file.read_bytes()) == report['planSha256']
matrix_file = Path('temp/requirement-automatic-2026-09-26-r4/report.json')
assert sha(matrix_file.read_bytes()) == report['priorReportSha256']
assert json.loads(matrix_file.read_text())['reservedUsd'] == report['priorReservedUsd']
for file, digest in plan['sourceHashes'].items():
	assert sha(Path(file).read_bytes()) == digest, file
files = []
for source, name in [(plan_file, 'context.plan.json.gz'), (report_file, 'context.report.json.gz'), (Path('temp/archive-context.py'), 'context.archive-source.py.gz'), (Path('temp/analyze-context.py'), 'context.analysis-source.py.gz'), (Path('temp/context-analysis.json'), 'context.analysis.json.gz')]:
	body = source.read_bytes(); target = out / name
	assert not target.exists(), name
	target.write_bytes(gzip.compress(body, mtime=0))
	files.append({'path': name, 'sha256': sha(target.read_bytes()), 'uncompressedSha256': sha(body)})
archive = out / 'context.source.tar.gz'; assert not archive.exists()
with tarfile.open(archive, 'w:gz') as bundle:
	for file in sorted(set(plan['sourceHashes']) | {'eval/contextContinuous.test.ts'}):
		bundle.add(file, arcname=file)
files.append({'path': archive.name, 'sha256': sha(archive.read_bytes())})
manifest = {'protocol': 'continuous-context-archive.v1', 'status': report['status'], 'planSha256': report['planSha256'], 'reportSha256': sha(report_file.read_bytes()), 'priorArchive': 'final.manifest.json', 'priorReportSha256': report['priorReportSha256'], 'totalUsdLimit': report['usdLimit'], 'priorReservedUsd': report['priorReservedUsd'], 'reservedUsd': report['reservedUsd'], 'phaseKnownUsageUsd': report['knownUsageUsd'], 'recordedWaves': len(report['waves']), 'sequences': report['sequences'], 'files': files}
(out / 'context.manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent='\t') + '\n')
print(json.dumps({key: manifest[key] for key in ['status', 'recordedWaves', 'reservedUsd', 'phaseKnownUsageUsd']}))
