import assert from 'node:assert/strict';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { AnthropicMessagesClient } from '../server/anthropic/client';
import { AnthropicModelProvider } from '../server/runtime/anthropicModelProvider';
import { ModelSettings } from '../server/modelSettings';
import { loadAutomaticSuite, scoreAutomatic } from '../eval/requirementAutomatic';
import { atomicReport, attemptSummary, onlyOutputLimitUnknowns, type Attempt } from '../eval/requirementAutomaticRun';
import { boundedProvider, reservedUsd, unresolved, type Ledger } from '../eval/requirementIntakeRun';
import { failureCode, newIntakeResult, sha256, type executeIntakeCase, type IntakeResult } from '../eval/requirementIntake';
const { values } = parseArgs({ options: { prepare: { type: 'boolean' }, online: { type: 'boolean' }, directory: { type: 'string' }, 'prior-report': { type: 'string' }, 'usd-limit': { type: 'string' } } });
assert(values.directory && values.prepare !== values.online, 'choose_prepare_or_online');
const directory = resolve(values.directory), root = resolve('temp/automatic-pending-change-repair');
const suite = loadAutomaticSuite(), matrix = JSON.parse(readFileSync('temp/requirement-automatic-2026-09-26-r3/plan.json', 'utf8'));
const ownPath = resolve('temp/pending-change-online.ts');
const hashes = () => Object.fromEntries(Object.keys(matrix.production.candidate).map(file => [file, sha256(readFileSync(join(root, file)))]));
const attempts: Attempt[] = [1, 2, 3].flatMap(repeat => ['AI-09', 'AI-13'].map(caseId => ({ id: `repair-${caseId}-${repeat}`, caseId, repeat, arm: 'candidate', model: 'deepseek-v4-flash' })));
if (values.prepare) {
	mkdirSync(directory);
	const sourceHashes = hashes();
	assert(Object.keys(sourceHashes).filter(file => sourceHashes[file] !== matrix.production.candidate[file]).join() === 'server/manufacturing/requirementBriefWorker.ts', 'repair_must_change_only_worker');
	const shared = Object.fromEntries(Object.keys(matrix.sharedHashes).map(file => [file, sha256(readFileSync(file))]));
	const plan = { protocol: 'pending-change-targeted-online.v1', sourceHashes, shared, runnerSha256: sha256(readFileSync(ownPath)), suiteSha256: suite.manifestSha256, root, attempts, maxOutputTokens: 8192, outputLimitPolicy: 'retain_reservation_skip_attempt_continue_independent', selection: 'AI-09 directly exposes verified-echo/new-proposal loss; AI-13 checks the same transition in a longer workflow. Selected after development results; not holdout.', originalMatrixPlanSha256: sha256(readFileSync('temp/requirement-automatic-2026-09-26-r3/plan.json')) };
	writeFileSync(join(directory, 'plan.json'), JSON.stringify(plan, null, '\t') + '\n', { flag: 'wx' });
	console.log(JSON.stringify({ mode: 'prepared_no_network', attempts: attempts.length }));
} else {
	assert(values['prior-report'] && !existsSync(join(directory, 'report.json')), 'new_report_and_prior_required');
	const planBytes = readFileSync(join(directory, 'plan.json')), plan = JSON.parse(planBytes.toString());
	assert.deepEqual(plan.sourceHashes, hashes(), 'frozen_source_changed');
	assert.equal(plan.runnerSha256, sha256(readFileSync(ownPath)), 'runner_changed');
	assert.equal(plan.suiteSha256, suite.manifestSha256, 'suite_changed');
	for (const [file, digest] of Object.entries(plan.shared)) assert.equal(sha256(readFileSync(file)), digest, 'shared_code_changed');
	for (const [file, digest] of Object.entries(matrix.production.candidate)) if (file !== 'server/manufacturing/requirementBriefWorker.ts') assert.equal(sha256(readFileSync(file)), digest, 'shared_adapter_changed');
	const priorBytes = readFileSync(values['prior-report']), prior = JSON.parse(priorBytes.toString());
	const usdLimit = Number(values['usd-limit']); assert(usdLimit === 20 && prior.usdLimit === usdLimit, 'total_cap_cannot_reset');
	assert(prior.protocol === 'continuous-context.v1' && ['completed', 'completed_insufficient_compaction', 'completed_with_failed_sequences'].includes(prior.status), 'prior_sequence_not_terminal');
	assert(prior.calls.every((c: { status: string; kind: string; error?: string; reservationUsd: number }) => Number.isFinite(c.reservationUsd) && c.reservationUsd >= 0 && (c.status === 'completed' || c.status === 'unknown' && c.kind === 'generate' && c.error === 'output_limit')), 'unreviewed_unknown');
	assert(Math.abs(reservedUsd(prior) - prior.reservedUsd) < 1e-9, 'prior_reservation_mismatch');
	const matrixBytes = readFileSync('temp/requirement-automatic-2026-09-26-r4/report.json');
	assert.equal(prior.priorReportSha256, sha256(matrixBytes), 'prior_chain_changed');
	assert.equal(prior.priorReservedUsd, JSON.parse(matrixBytes.toString()).reservedUsd, 'prior_chain_budget_changed');
	const ledger: Ledger = { usdLimit, calls: [], priorReservedUsd: prior.reservedUsd };
	assert(reservedUsd(ledger) < usdLimit, 'no_remaining_budget');
	writeFileSync(join(directory, 'runner.lock'), `${process.pid}\n`, { flag: 'wx' });
	const env = { ...process.env }; new ModelSettings(resolve(env.PACKX_SETTINGS_PATH ?? '.packx-settings.json'), env).apply(env);
	assert(env.ANTHROPIC_API_KEY && env.ANTHROPIC_BASE_URL?.replace(/\/$/, '') === 'https://api.deepseek.com/anthropic', 'official_provider_required');
	const upstream = new AnthropicModelProvider(new AnthropicMessagesClient({ baseUrl: env.ANTHROPIC_BASE_URL, apiKey: env.ANTHROPIC_API_KEY }), 'deepseek-v4-flash', 8192);
	const execute = (await import(pathToFileURL(join(root, 'eval/requirementIntake.ts')).href)).executeIntakeCase as typeof executeIntakeCase;
	const results: ReturnType<typeof attemptSummary>[] = [];
	let active: { attempt: Attempt; result: IntakeResult } | undefined, status = 'running', budgetStopped = false;
	const save = () => {
		if (active) atomicReport(join(directory, active.attempt.id + '.json'), { ...active, calls: ledger.calls.filter(c => c.caseId === active!.attempt.id) });
		atomicReport(join(directory, 'report.json'), { protocol: plan.protocol, planSha256: sha256(planBytes), priorReportSha256: sha256(priorBytes), status, usdLimit, priorReservedUsd: ledger.priorReservedUsd, reservedUsd: reservedUsd(ledger), planned: attempts.length, recorded: results.length, semanticQuality: 'NOT_EVALUATED', results, calls: ledger.calls });
	};
	save();
	try {
		for (const attempt of attempts) {
			const input = suite.cases.find(c => c.id === attempt.caseId)!, oracle = suite.oracles.find(o => o.caseId === attempt.caseId)!, result = newIntakeResult(input);
			active = { attempt, result }; save();
			const local: Ledger = { usdLimit, calls: [], priorReservedUsd: reservedUsd(ledger) }; let copied = 0;
			const bounded = boundedProvider(upstream, local, attempt.id, () => input.events[result.nextEvent]?.id ?? 'end', () => { ledger.calls.push(...local.calls.slice(copied)); copied = local.calls.length; save(); });
			const provider = { ...bounded, async generate(...args: Parameters<typeof bounded.generate>) { try { return await bounded.generate(...args); } catch (error) { if (failureCode(error) === 'usd_limit') budgetStopped = true; throw error; } } };
			await execute({ input, oracle, result, directory: join(directory, 'state', attempt.id), provider, environment: { PACKX_MODEL_MAX_OUTPUT_TOKENS: '8192' }, score: scoreAutomatic, save });
			const summary = attemptSummary(attempt, result, ledger.calls); results.push(summary); save(); console.log(JSON.stringify(summary));
			if (unresolved(local) && !onlyOutputLimitUnknowns(local.calls)) { status = 'stopped_unknown'; break; }
			if (budgetStopped || reservedUsd(ledger) >= usdLimit) { status = 'stopped_budget'; break; }
		}
		if (status === 'running') status = 'completed';
	} catch (error) { status = unresolved(ledger) ? 'stopped_unknown' : 'stopped_error'; throw error; }
	finally { save(); }
}
