import collections, gzip, hashlib, json
from pathlib import Path

out = Path('docs/evidence/automatic-online-2026-09-26')
paths = [Path('temp/requirement-automatic-2026-09-26-r4/report.json'), Path('temp/context-continuous-2026-09-26-r5.report.json'), Path('temp/pending-change-online-2026-09-26-r3/report.json')]
matrix, context, repair = reports = [json.loads(path.read_text()) for path in paths]
assert all(report['status'] != 'running' and report['usdLimit'] == 20 for report in reports)
for index in [1, 2]:
	assert reports[index]['priorReportSha256'] == hashlib.sha256(paths[index - 1].read_bytes()).hexdigest()
	assert reports[index]['priorReservedUsd'] == reports[index - 1]['reservedUsd']
matrix_calls = []; link = matrix
while True:
	assert abs(link.get('priorReservedUsd', 0) + sum(call['reservationUsd'] for call in link['calls']) - link['reservedUsd']) < 1e-8
	matrix_calls.extend(link['calls'])
	if not link.get('priorMatrix'): break
	prior = Path(link['priorMatrix']['path'])
	assert hashlib.sha256(prior.read_bytes()).hexdigest() == link['priorMatrix']['sha256']
	link = json.loads(prior.read_text())
phases = []
for name, report, path, calls in zip(['matrix', 'continuous_context', 'pending_change_repair'], reports, paths, [matrix_calls, context['calls'], repair['calls']]):
	assert all(call['status'] != 'started' for call in calls), 'terminal report retains active request'
	known = report.get('knownUsageUsd', sum(row['knownUsageUsd'] for row in report.get('results', [])))
	phase_reserved = sum(call['reservationUsd'] for call in calls)
	if name != 'matrix': assert abs(report['priorReservedUsd'] + phase_reserved - report['reservedUsd']) < 1e-8
	phases.append({'phase': name, 'status': report['status'], 'reportSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'phaseKnownUsageUsd': known, 'phaseReservedUsd': phase_reserved, 'cumulativeReservedUsd': report['reservedUsd'], 'generations': sum(call['kind'] == 'generate' for call in calls), 'countRequests': sum(call['kind'] == 'count' for call in calls), 'unresolvedUsage': dict(collections.Counter(call.get('error', call['status']) for call in calls if call['status'] != 'completed'))})
assert repair['reservedUsd'] <= 20
assert abs(sum(phase['phaseReservedUsd'] for phase in phases) - repair['reservedUsd']) < 1e-8
result = {'protocol': 'online-evaluation-budget-summary.v1', 'authorizedUsdLimit': 20, 'knownUsageEstimateUsd': sum(phase['phaseKnownUsageUsd'] for phase in phases), 'reservedUsd': repair['reservedUsd'], 'unallocatedUpperBoundUsd': 20 - repair['reservedUsd'], 'retainedUnresolvedUsageCalls': sum(sum(phase['unresolvedUsage'].values()) for phase in phases), 'phases': phases, 'notes': ['Known usage uses frozen peak prices; it is not an invoice and excludes unavailable usage.', 'Every per-request upper reservation is retained, including completed responses. No unused reservation was refunded or reused.', 'Received output_limit is a known failed generation with lost usage; terminated is an unreconciled remote outcome.', 'Prior Sept 25 ledgers and their eight unresolved calls remain separate historical evidence; this is one newly authorized USD 20 experiment.']}
target = out / 'budget-summary.json'; assert not target.exists()
target.write_text(json.dumps(result, ensure_ascii=False, indent='\t') + '\n')
source = Path('temp/finalize-online-budget.py').read_bytes(); (out / 'budget-summary-source.py.gz').write_bytes(gzip.compress(source, mtime=0))
print(json.dumps(result, ensure_ascii=False))
