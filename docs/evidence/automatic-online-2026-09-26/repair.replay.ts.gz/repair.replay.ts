import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { loadAutomaticSuite, scoreAutomatic } from '../eval/requirementAutomatic';
import { newIntakeResult, sha256, verdict, type executeIntakeCase } from '../eval/requirementIntake';
import type { AgentModelRequest } from '../src/agent/contracts';
const source = resolve('temp/requirement-automatic-2026-09-26-r3/flash-candidate-AI-09-2.json');
const bytes = readFileSync(source), captured = JSON.parse(bytes.toString());
assert(captured.result.status === 'completed');
const suite = loadAutomaticSuite(), input = suite.cases.find(c => c.id === 'AI-09')!, oracle = suite.oracles.find(o => o.caseId === input.id)!;
const results = [];
for (const [name, root] of [['before', 'temp/requirement-automatic-2026-09-26-r3/candidate'], ['after', 'temp/automatic-pending-change-repair']]) {
	const result = newIntakeResult(input);
	const calls = captured.calls.filter((c: { kind: string }) => c.kind === 'generate');
	assert(calls.every((c: { status: string }) => c.status === 'completed'));
	const consumed = new Set<number>();
	const purpose = (r: AgentModelRequest) => r.outputSchema?.properties && 'issues' in (r.outputSchema.properties as object) ? 'evidence_review' : 'intake';
	const provider = { async countTokens() { return 1000; }, async generate(request: AgentModelRequest) {
		const eventId = input.events[result.nextEvent].id;
		const index = calls.findIndex((c: { eventId: string; purpose: string }, i: number) => !consumed.has(i) && c.eventId === eventId && c.purpose === purpose(request));
		assert(index >= 0, 'replay_exhausted'); consumed.add(index);
		return structuredClone(calls[index].response);
	} };
	const execute = (await import(pathToFileURL(resolve(root, 'eval/requirementIntake.ts')).href)).executeIntakeCase as typeof executeIntakeCase;
	await execute({ input, oracle, result, directory: resolve('temp/pending-change-replay-' + name), provider, environment: { PACKX_MODEL_MAX_OUTPUT_TOKENS: '8192' }, score: scoreAutomatic, save() {} });
	results.push({ name, workerSha256: sha256(readFileSync(resolve(root, 'server/manufacturing/requirementBriefWorker.ts'))), status: result.status, error: result.error, verdict: verdict(result), recordedModelResponsesUsed: consumed.size, checkpoints: result.checkpoints.map(p => ({ id: p.capture.id, verdict: p.verdict, failedChecks: p.checks.filter(c => c.status !== 'passed'), quantity: p.capture.brief.facts.find(f => f.key === 'quantity'), pendingChanges: p.capture.brief.pendingChanges ?? [], nextAction: p.capture.brief.nextAction, approvalEligible: p.capture.evaluation.approvalEligible, actualApproval: p.capture.state.approval?.status ?? null })) });
}
const report = { protocol: 'pending-change-captured-response-replay.v1', paidCalls: 0, mode: 'offline-replay-of-fixed-real-model-responses', sourceAttempt: captured.attempt.id, sourceSha256: sha256(bytes), suiteSha256: suite.manifestSha256, limitations: ['Uses exactly the same previously received model responses on both code versions; no fresh model generation.', 'Changed Host state may alter review inputs; recorded review responses are deliberately fixed, not rejudged.', 'This isolates Host state handling and does not estimate fresh online task success.'], results };
writeFileSync('docs/evidence/pending-change-replay-2026-09-26.json', JSON.stringify(report, null, '\t') + '\n', { flag: 'wx' });
console.log(JSON.stringify(report));
