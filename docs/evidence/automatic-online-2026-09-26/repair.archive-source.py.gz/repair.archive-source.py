import gzip, hashlib, json, tarfile
from pathlib import Path

out = Path('docs/evidence/automatic-online-2026-09-26')
root = Path('temp/pending-change-online-2026-09-26-r3')
sha = lambda body: hashlib.sha256(body).hexdigest()
plan, report = [json.loads((root / file).read_text()) for file in ['plan.json', 'report.json']]
assert report['status'] != 'running'
assert sha((root / 'plan.json').read_bytes()) == report['planSha256']
prior_file = Path('temp/context-continuous-2026-09-26-r5.report.json')
assert sha(prior_file.read_bytes()) == report['priorReportSha256']
assert json.loads(prior_file.read_text())['reservedUsd'] == report['priorReservedUsd']
for file, digest in plan['sourceHashes'].items():
	assert sha((Path(plan['root']) / file).read_bytes()) == digest, file
for file, digest in plan['shared'].items():
	assert sha(Path(file).read_bytes()) == digest, file
assert sha(Path('temp/pending-change-online.ts').read_bytes()) == plan['runnerSha256']
files = []
sources = [(root / file, 'repair.' + file + '.gz') for file in ['plan.json', 'report.json']]
sources += [(Path('temp/repair-analysis.json'), 'repair.analysis.json.gz'), (Path('temp/analyze-repair.py'), 'repair.analysis-source.py.gz')]
sources += [(Path('temp/repair-tool-reconciliation.json'), 'repair.tool-reconciliation.json.gz'), (Path('temp/reconcile-repair-tools.py'), 'repair.tool-reconciliation-source.py.gz')]
sources += [(root / (row['id'] + '.json'), row['id'] + '.json.gz') for row in report['results']]
sources += [(Path(source), name + '.gz') for source, name in [('temp/pending-change-online.ts', 'repair.runner.ts'), ('temp/replay-pending-change.ts', 'repair.replay.ts'), ('temp/pending-change-repair.patch', 'repair.patch'), ('temp/pending-change-repair-verification.json', 'repair.offline-verification.json'), ('temp/final-check-2026-09-26.log', 'verification.log'), ('docs/evidence/automatic-online-2026-09-26/verification.json', 'verification.json'), ('temp/archive-repair.py', 'repair.archive-source.py')]]
for source, name in sources:
	body = source.read_bytes(); target = out / name
	assert not target.exists(), name
	target.write_bytes(gzip.compress(body, mtime=0))
	files.append({'path': name, 'sha256': sha(target.read_bytes()), 'uncompressedSha256': sha(body)})
archive = out / 'repair.source.tar.gz'; assert not archive.exists()
with tarfile.open(archive, 'w:gz') as bundle:
	for file in sorted(plan['sourceHashes']): bundle.add(Path(plan['root']) / file, arcname=file)
	for file in sorted(plan['shared']): bundle.add(file, arcname=file)
	bundle.add('server/manufacturing/requirementIntake.regression.test.ts', arcname='server/manufacturing/requirementIntake.regression.test.ts')
files.append({'path': archive.name, 'sha256': sha(archive.read_bytes())})
manifest = {'protocol': 'pending-change-repair-archive.v1', 'status': report['status'], 'planSha256': report['planSha256'], 'reportSha256': sha((root / 'report.json').read_bytes()), 'priorArchive': 'context.manifest.json', 'priorReportSha256': report['priorReportSha256'], 'totalUsdLimit': report['usdLimit'], 'priorReservedUsd': report['priorReservedUsd'], 'reservedUsd': report['reservedUsd'], 'phaseKnownUsageUsd': sum(row['knownUsageUsd'] for row in report['results']), 'plannedAttempts': report['planned'], 'recordedAttempts': report['recorded'], 'notes': ['Six fresh development regressions selected after observed failures; not holdout and not an updated 12-case matrix.', 'Prior reservations and unresolved usage are retained without replay.'], 'files': files}
(out / 'repair.manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent='\t') + '\n')
print(json.dumps({key: manifest[key] for key in ['status', 'recordedAttempts', 'reservedUsd', 'phaseKnownUsageUsd']}))
