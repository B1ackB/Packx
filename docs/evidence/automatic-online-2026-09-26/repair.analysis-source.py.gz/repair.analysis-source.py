import collections, hashlib, json
from pathlib import Path

root = Path('temp/pending-change-online-2026-09-26-r3')
report = json.loads((root / 'report.json').read_text())
attempts = []
for row in report['results']:
	path = root / (row['id'] + '.json'); raw = json.loads(path.read_text())
	points = []
	for point in raw['result']['checkpoints']:
		capture = point['capture']; brief = capture.get('brief') or {}
		candidate = (capture['candidates'][-1].get('candidate') or {}) if capture.get('candidates') else {}
		points.append({'id': capture['id'], 'verdict': point['verdict'], 'pendingChanges': brief.get('pendingChanges', []), 'quantity': capture['state']['facts'].get('quantity'), 'latestRawQuantityCandidates': [fact for fact in candidate.get('facts', []) if fact['key'] == 'quantity'], 'nextAction': brief.get('nextAction'), 'failedOrUnresolvedChecks': [check for check in point['checks'] if check['status'] != 'passed']})
	attempts.append({**row, 'sourceSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'points': points, 'modelErrors': [{key: call.get(key) for key in ['purpose', 'eventId', 'status', 'error', 'reservationUsd']} for call in raw['calls'] if call['status'] != 'completed']})
result = {'protocol': 'pending-change-targeted-analysis.v1', 'status': report['status'], 'reportSha256': hashlib.sha256((root / 'report.json').read_bytes()).hexdigest(), 'plannedAttempts': report['planned'], 'recordedAttempts': report['recorded'], 'outcomes': dict(collections.Counter(row['verdict'] for row in report['results'])), 'reachedCheckpoints': sum(row['checkpoints'] for row in report['results']), 'plannedCheckpoints': 27, 'knownUsageUsd': sum(row['knownUsageUsd'] for row in report['results']), 'phaseReservedUsd': sum(call['reservationUsd'] for call in report['calls']), 'totalReservedUsd': report['reservedUsd'], 'unknownCalls': sum(call['status'] != 'completed' for call in report['calls']), 'attempts': attempts, 'notes': ['Six new attempts on two previously observed development scenarios; not a new 12-case matrix or holdout.', 'Pending-change checkpoints and whole-task completion are separate outcomes.', 'Captured-response replay is archived separately; this file describes fresh model calls.']}
Path('temp/repair-analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent='\t') + '\n')
print(json.dumps({key: result[key] for key in ['status', 'recordedAttempts', 'outcomes', 'reachedCheckpoints', 'knownUsageUsd', 'phaseReservedUsd', 'totalReservedUsd', 'unknownCalls']}))
