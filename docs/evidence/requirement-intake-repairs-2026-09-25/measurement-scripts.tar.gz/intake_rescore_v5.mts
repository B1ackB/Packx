import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {loadIntakeSuite,regrade,verdict,sha256} from '/Users/black/Documents/VSCodeProject/SmallBlack/eval/requirementIntake.ts';
const out='/Users/black/Documents/VSCodeProject/SmallBlack/docs/evidence/requirement-intake-repairs-2026-09-25/';
const suite=loadIntakeSuite(),deltas=[];
for(const [label,file] of [['baseline','../requirement-intake-2026-09-25/baseline.report.json.gz'],['trial-a','trial-a.report.json.gz'],['trial-b','trial-b.report.json.gz']]){
 const bytes=gunzipSync(readFileSync(out+file)),report=JSON.parse(bytes.toString()),before=structuredClone(report.results),changes=[];
 for(const r of report.results){
  regrade(r,suite.oracles.find(o=>o.caseId===r.caseId)!,report.reviews);
  for(const p of r.checkpoints){const old=before.find(x=>x.caseId===r.caseId).checkpoints.find(x=>x.capture.id===p.capture.id);for(const c of p.checks){const previous=old.checks.find(x=>x.id===c.id);if(c.status!==previous.status)changes.push({caseId:r.caseId,checkpointId:p.capture.id,captureSha256:p.captureSha256,checkId:c.id,before:previous.status,after:c.status,expected:c.expected,actual:c.actual});}}
 }
 deltas.push({label,reportSha256:sha256(bytes),changes,tasksPassed:report.results.filter(r=>verdict(r)==='passed').length,checkpointsPassed:report.results.flatMap(r=>r.checkpoints).filter(p=>p.verdict==='passed').length,reached:report.results.flatMap(r=>r.checkpoints).length});
}
writeFileSync('/private/tmp/intake-rescore-v5-pending.json',JSON.stringify({protocol:'scoring-v5',scoringProtocolSha256:sha256(readFileSync(out+'../../../eval/fixtures/requirement-intake-v1/scoring-v5.md')),deltas},null,'\t')+'\n');
console.log(JSON.stringify(deltas));
