from pathlib import Path
from collections import Counter
import json,statistics,hashlib
root=Path('/private/tmp/packx-intake-repairs-v5-finish2-20260925')
r=json.loads((root/'report.json').read_text())
cases=json.loads(Path('eval/fixtures/requirement-intake-v1/cases.json').read_text())
oracles=json.loads(Path('eval/fixtures/requirement-intake-v1/oracles.json').read_text())
bycase={c['id']:c for c in cases}
byoracle={c['caseId']:c for c in oracles}
rows=[]
for x in r['results']:
 checks=[c for p in x['checkpoints'] for c in p['checks']]
 failed=x['status']=='failed' or any(c['status']=='failed' for c in checks)
 pending=x['status']!='completed' or any(c['status']=='needs_review' for c in checks)
 calls=[c for c in r['calls'] if c['caseId']==x['caseId'] and c['kind']=='generate']
 tools=[e for e in x['traceEvents'] if e['type']=='tool.completed']
 rows.append(dict(caseId=x['caseId'],title=bycase[x['caseId']]['title'],family=bycase[x['caseId']]['family'],executionStatus=x['status'],verdict='failed' if failed else 'needs_review' if pending else 'passed',checkpointReached=len(x['checkpoints']),checkpointsExpected=len(byoracle[x['caseId']]['checkpoints']),checkpointPass=sum(p['verdict']=='passed' for p in x['checkpoints']),generations=len(calls),toolCalls=len(tools),toolFailures=sum(e['status']!='succeeded' for e in tools),durationMs=x['executionDurationMs'],failedChecks=[{'checkpoint':p['capture']['id'],'id':c['id'],'expected':c['expected'],'actual':c.get('actual')} for p in x['checkpoints'] for c in p['checks'] if c['status']=='failed'],error=x.get('error'),operations=x['operations'][-2:]))
allpoints=[p for x in r['results'] for p in x['checkpoints']]
checkcounts=Counter(c['status'] for p in allpoints for c in p['checks'])
usage=Counter()
for c in r['calls']:
 usage.update(c.get('response',{}).get('usage',{}))
gens=[c for c in r['calls'] if c['kind']=='generate']
usageusd=(usage['inputTokens']*.3+usage['cachedInputTokens']*.006+usage['outputTokens']*1.2)/1e6
reviewcalls=[c for c in gens if c['purpose']=='evidence_review']
leaks=[]
for c in r['calls']:
 case=bycase[c['caseId']]; idx=next(i for i,e in enumerate(case['events']) if e['id']==c['eventId'])
 delivered={e['sourceId'] for e in case['events'][:idx+1] if e['kind']=='deliver_source'}
 text=json.dumps(c['request'],ensure_ascii=False)
 for other in cases:
  for s in other['sources']:
   if (other['id']!=case['id'] or s['id'] not in delivered) and s['id'] in text:leaks.append([c['caseId'],c['eventId'],s['id']])
 assert hashlib.sha256(json.dumps(c['request'],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()==c['requestSha256'],'request digest mismatch'
metrics=dict(protocol=r['protocol'],caseCount=len(rows),caseVerdicts=dict(Counter(x['verdict'] for x in rows)),checkpointObserved=len(allpoints),checkpointExpected=sum(x['checkpointsExpected'] for x in rows),checkpointVerdicts=dict(Counter(p['verdict'] for p in allpoints)),checks=dict(checkcounts),generations=len(gens),counts=sum(c['kind']=='count' for c in r['calls']),generationPurposes=dict(Counter(c['purpose'] for c in gens)),reviewModelCallsRequestingTools=sum(bool(c.get('response',{}).get('toolCalls')) for c in reviewcalls),productionEvaluations=dict(Counter(p['capture']['evaluation'].get('evidenceReview',{}).get('failure') or p['capture']['evaluation'].get('evidenceReview',{}).get('status') for p in allpoints)),productionApprovalEligible=sum(p['capture']['evaluation']['approvalEligible'] for p in allpoints),tools=sum(x['toolCalls'] for x in rows),toolFailures=sum(x['toolFailures'] for x in rows),compactions=sum(e['type']=='context.compacted' for x in r['results'] for e in x['traceEvents']),usage=dict(usage),estimatedUsageUsd=usageusd,priorReservedUsd=r['priorReservedUsd'],reservedUsd=r['priorReservedUsd']+sum(c['reservationUsd'] for c in r['calls']),cumulativeKnownUsageUsd=usageusd+r.get('reviewedStop',{}).get('estimatedUsageUsd',0),currentUnknown=sum(c['status']!='completed' for c in r['calls']),priorUnknown=len(r.get('reviewedStop',{}).get('unknown',[])),caseSecondsMedian=statistics.median(x['durationMs']/1000 for x in rows),caseSecondsMin=min(x['durationMs']/1000 for x in rows),caseSecondsMax=max(x['durationMs']/1000 for x in rows),totalExecutionSeconds=sum(x['durationMs']/1000 for x in rows),semanticReviews=len(r['reviews']),sourceIdLeakFindings=leaks,rows=rows)
Path('/private/tmp/intake-metrics-v5.json').write_text(json.dumps(metrics,ensure_ascii=False,indent='\t')+'\n')
print(json.dumps({k:v for k,v in metrics.items() if k!='rows'},ensure_ascii=False))
print(json.dumps([{k:v for k,v in row.items() if k not in ['failedChecks','operations']} for row in rows],ensure_ascii=False))
