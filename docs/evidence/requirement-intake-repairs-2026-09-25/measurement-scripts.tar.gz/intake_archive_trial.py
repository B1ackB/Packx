from pathlib import Path
import sys,json,hashlib,gzip,tarfile,shutil,re
root=Path(sys.argv[1]);label=sys.argv[2];code=Path(sys.argv[3]);metrics=Path(sys.argv[4])
out=Path('docs/evidence/requirement-intake-repairs-2026-09-25');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(root/'report.json').read_bytes();r=json.loads(raw);m=json.loads(metrics.read_text())
assert not(root/'runner.lock').exists();assert all(x['status'] in ['completed','failed'] for x in r['results']);assert all(c['status'] in ['completed','unknown'] for c in r['calls']);assert not m['checks'].get('needs_review');assert m['sourceIdLeakFindings']==[]
with tarfile.open(code) as t:
 for file,h in r['sourceHashes'].items():assert sha(t.extractfile(file).read())==h,file
chain=[]
for item in r.get('continuations',[]):
 parentraw=(Path(item['sourceDirectory'])/'report.json').read_bytes();p=json.loads(parentraw)
 assert sha(parentraw)==item['sourceReportSha256'];assert r['calls'][:len(p['calls'])]==p['calls'];assert all(c['caseId'] not in item['excludedCaseIds'] for c in r['calls'][len(p['calls']):])
 for old in p['results']:
  new=next(x for x in r['results'] if x['caseId']==old['caseId'])
  for pt in old['checkpoints']:
   newpt=next(x for x in new['checkpoints'] if x['capture']['id']==pt['capture']['id']);assert pt['capture']==newpt['capture'] and pt['captureSha256']==newpt['captureSha256']
 chain.append({'parentSha256':sha(parentraw),'excluded':item['excludedCaseIds'],'callsPreserved':len(p['calls'])})
assert not (out/(label+'.report.json.gz')).exists()
(out/(label+'.report.json.gz')).write_bytes(gzip.compress(raw,mtime=0));shutil.copyfile(code,out/(label+'.source.tar.gz'))
with tarfile.open(out/(label+'.state.tar.gz'),'w:gz') as t:
 for d in sorted(root.glob('RI-*')):t.add(d,arcname='state/'+d.name)
 for i,item in enumerate(r.get('continuations',[])):t.add(Path(item['sourceDirectory'])/'report.json',arcname=f'parent-{i}.report.json')
 if label in ['trial-a','trial-b','trial-c']:
  t.add('/private/tmp/intake_continue_'+{'trial-a':'v3','trial-b':'v4','trial-c':'v5'}[label]+'.mts',arcname='operator/continuation.mts')
 for name in [f'intake-reviews-{sys.argv[5]}.json'] if len(sys.argv)>5 else []:t.add('/private/tmp/'+name,arcname='operator/'+name)
scan=re.compile(rb'(?:sk-[A-Za-z0-9_-]{24,}|Bearer\s+[A-Za-z0-9_-]{30,})');assert not scan.search(raw)
with tarfile.open(out/(label+'.state.tar.gz')) as t:
 for x in t.getmembers():
  if x.isfile():assert not scan.search(t.extractfile(x).read()),x.name
m.update(finalReportSha256=sha(raw),sourceSha256=r['sourceSha256'],model=r['model'],manifestSha256=r['manifestSha256'],scoringProtocolSha256=r['scoringProtocolSha256'],usdLimit=r['usdLimit'],holdoutModelRuns=0)
(out/(label+'.summary.json')).write_text(json.dumps(m,ensure_ascii=False,indent='\t')+'\n')
audit={'reportSha256':sha(raw),'priorReportSha256':r['reviewedStop']['reportSha256'],'codeFilesVerified':len(r['sourceHashes']),'continuations':chain,'allCallsAndCapturesPreserved':True,'unknownsRetained':r['reviewedStop']['unknown']+[{k:c[k] for k in ['caseId','requestSha256','status','reservationUsd','error']} for c in r['calls'] if c['status']=='unknown'],'holdoutModelRuns':0,'sourceIdLeakFindings':[],'semanticReview':'codex_assisted; case author; unblinded and uncalibrated','credentialLiteralScan':'passed; limited pattern scan, not a general privacy proof'}
(out/(label+'.audit.json')).write_text(json.dumps(audit,ensure_ascii=False,indent='\t')+'\n')
print({'archived':label,'passedTasks':m['caseVerdicts'].get('passed',0),'observedCheckpoints':m['checkpointObserved'],'passedCheckpoints':m['checkpointVerdicts'].get('passed',0),'allUnknowns':len(audit['unknownsRetained'])})
