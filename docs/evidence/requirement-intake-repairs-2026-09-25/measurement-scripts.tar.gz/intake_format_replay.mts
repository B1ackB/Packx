import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {parseRequirementCandidate} from '/Users/black/Documents/VSCodeProject/SmallBlack/server/manufacturing/requirementBriefWorker.ts';
import {sha256} from '/Users/black/Documents/VSCodeProject/SmallBlack/eval/requirementIntake.ts';
const raw=gunzipSync(readFileSync('docs/evidence/requirement-intake-repairs-2026-09-25/trial-a.report.json.gz'));
const report=JSON.parse(raw.toString());const rows=[];
for(const c of report.calls){
 if(c.kind!=='generate'||c.purpose!=='intake'||!c.response||c.response.toolCalls.length)continue;
 try{JSON.parse(c.response.text);continue;}catch{}
 const parsed=parseRequirementCandidate(c.response.text,'print');
 rows.push({caseId:c.caseId,eventId:c.eventId,outputSha256:sha256(c.response.text),wrapped:c.response.text.trim().startsWith('```'),accepted:Boolean(parsed),...(parsed?{parsedSha256:sha256(JSON.stringify(parsed))}:{})});
}
const result={mode:'offline replay of saved real model outputs, not new task success',sourceReportSha256:sha256(raw),rows};
writeFileSync('docs/evidence/requirement-intake-repairs-2026-09-25/format-replay.json',JSON.stringify(result,null,'\t')+'\n');console.log(JSON.stringify(result));
