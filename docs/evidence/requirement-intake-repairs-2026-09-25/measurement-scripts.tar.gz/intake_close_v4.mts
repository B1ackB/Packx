import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {regrade,loadIntakeSuite} from '/private/tmp/packx-frozen-v4/eval/requirementIntake.ts';
const file='/private/tmp/packx-intake-repairs-v4-finish2-20260925/report.json',r=JSON.parse(readFileSync(file,'utf8'));
for(const item of JSON.parse(readFileSync('/private/tmp/intake-reviews-v4.json','utf8'))){const old=r.reviews.find(x=>x.caseId===item.caseId&&x.checkpointId===item.checkpointId&&x.checkId===item.checkId);if(old)assert.deepEqual(old,item);else r.reviews.push(item);}
const suite=loadIntakeSuite();for(const result of r.results)regrade(result,suite.oracles.find(o=>o.caseId===result.caseId)!,r.reviews);
assert(r.results.every(x=>x.status==='completed'||x.status==='failed'));
assert(r.results.every(x=>x.checkpoints.every(p=>p.checks.every(c=>c.status!=='needs_review'))));
r.updatedAt=new Date().toISOString();writeFileSync(file,JSON.stringify(r,null,'\t')+'\n');
