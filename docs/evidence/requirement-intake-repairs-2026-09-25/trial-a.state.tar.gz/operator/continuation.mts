import assert from 'node:assert/strict';
import {cpSync,existsSync,mkdirSync,readFileSync,writeFileSync,renameSync,openSync,fsyncSync,closeSync,rmSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {parseArgs} from 'node:util';
import {loadIntakeSuite,regrade,executeIntakeCase,intakeLimits,sha256,verdict} from '/Users/black/Documents/VSCodeProject/SmallBlack/eval/requirementIntake.ts';
import {boundedProvider,reservedUsd,summarize} from '/Users/black/Documents/VSCodeProject/SmallBlack/eval/requirementIntakeRun.ts';
import {ModelSettings} from '/Users/black/Documents/VSCodeProject/SmallBlack/server/modelSettings.ts';
import {AnthropicMessagesClient} from '/Users/black/Documents/VSCodeProject/SmallBlack/server/anthropic/client.ts';
import {AnthropicModelProvider} from '/Users/black/Documents/VSCodeProject/SmallBlack/server/runtime/anthropicModelProvider.ts';
const {values}=parseArgs({options:{source:{type:'string'},directory:{type:'string'},online:{type:'boolean'},reviews:{type:'string'}}});
assert(values.source&&values.directory);
const source=resolve(values.source),directory=resolve(values.directory),bytes=readFileSync(join(source,'report.json'),'utf8'),report=JSON.parse(bytes),suite=loadIntakeSuite();
assert(report.protocol==='requirement-intake-online.v3' && report.usdLimit===20);
assert(report.status!=='running' && !existsSync(join(source,'runner.lock')));
assert(report.manifestSha256===suite.manifestSha256);
for(const [file,hash] of Object.entries(report.sourceHashes))assert(sha256(readFileSync(file))===hash,`source_changed:${file}`);
assert(sha256(readFileSync('eval/fixtures/requirement-intake-v1/scoring-v3.md'))===report.scoringProtocolSha256);
const unknown=report.calls.filter(c=>c.status!=='completed');
assert(unknown.every(c=>c.status==='unknown'&&['runtime_timeout','output_limit'].includes(c.error)));
const excluded=new Set(unknown.map(c=>c.caseId));
for(const id of excluded)assert(['completed','failed'].includes(report.results.find(r=>r.caseId===id).status));
if(values.reviews){
	for(const item of JSON.parse(readFileSync(resolve(values.reviews),'utf8'))){
		const old=report.reviews.find(x=>x.caseId===item.caseId&&x.checkpointId===item.checkpointId&&x.checkId===item.checkId);
		if(old)assert.deepEqual(old,item);else report.reviews.push(item);
	}
}
for(const result of report.results)regrade(result,suite.oracles.find(o=>o.caseId===result.caseId)!,report.reviews);
const selected=report.results.filter(r=>r.status==='needs_review'&&!excluded.has(r.caseId));
console.log(JSON.stringify({plan:'continue_only_other_case_scopes',cases:selected.map(r=>r.caseId),excluded:[...excluded],priorReservedUsd:reservedUsd(report),cap:20}));
if(!values.online)process.exit(0);
assert(!existsSync(directory)); cpSync(source,directory,{recursive:true,errorOnExist:true,force:false});
mkdirSync(join(directory,'runner.lock'));
report.continuations??=[];
report.continuations.push({sourceReportSha256:sha256(bytes),sourceDirectory:source,excludedCaseIds:[...excluded],retainedUnknowns:unknown.map(c=>({caseId:c.caseId,requestSha256:c.requestSha256,status:c.status,reservationUsd:c.reservationUsd,error:c.error})),driverSha256:sha256(readFileSync('/private/tmp/intake_continue_v3.mts')),reason:'Operator reviewed terminal cases after a bounded review timeout. Retain all calls and reservations; never replay unknown scopes. Continue only independently persisted waiting cases under the authorized cumulative USD 20 cap.',startedAt:new Date().toISOString()});
const file=join(directory,'report.json');
const save=()=>{report.updatedAt=new Date().toISOString();const fd=openSync(file+'.next','wx',0o600);try{writeFileSync(fd,JSON.stringify(report,null,'\t')+'\n');fsyncSync(fd);}finally{closeSync(fd);}renameSync(file+'.next',file);};
const environment={...process.env};new ModelSettings(resolve(environment.PACKX_SETTINGS_PATH??'.packx-settings.json'),environment).apply(environment);
assert(environment.ANTHROPIC_MODEL===report.model&&environment.ANTHROPIC_BASE_URL===report.endpoint&&environment.ANTHROPIC_API_KEY);
environment.PACKX_MODEL_MAX_OUTPUT_TOKENS=String(intakeLimits.maxOutputTokens);
const provider=new AnthropicModelProvider(new AnthropicMessagesClient({baseUrl:report.endpoint,apiKey:environment.ANTHROPIC_API_KEY}),report.model,intakeLimits.maxOutputTokens);
try{
	report.status='running';save();
	for(const result of selected){
		const own=report.calls.filter(c=>c.caseId===result.caseId);
		assert(own.every(c=>c.status==='completed'));
		const ledger={usdLimit:20,priorReservedUsd:reservedUsd(report)-own.reduce((s,c)=>s+c.reservationUsd,0),calls:own};
		const sync=()=>{for(const call of ledger.calls)if(!report.calls.includes(call))report.calls.push(call);save();};
		const input=suite.cases.find(c=>c.id===result.caseId)!;
		console.log(JSON.stringify({case:input.id,status:'continuing',event:result.nextEvent}));
		await executeIntakeCase({input,oracle:suite.oracles.find(o=>o.caseId===input.id)!,result,directory:join(directory,input.id),provider:boundedProvider(provider,ledger,input.id,()=>input.events[result.nextEvent]?.id??'end',sync),environment,reviews:report.reviews,save:sync});
		console.log(JSON.stringify({case:input.id,status:result.status,verdict:verdict(result),error:result.error,reservedUsd:reservedUsd(report)}));
		if(ledger.calls.some(c=>c.status!=='completed'))break;
	}
	report.status=report.calls.some(c=>c.status!=='completed'&&!excluded.has(c.caseId))?'stopped_unknown':report.results.some(r=>r.status==='needs_review')?'awaiting_review':'finished_with_retained_unknowns';save();
	console.log(JSON.stringify(summarize(report)));
}finally{rmSync(join(directory,'runner.lock'),{recursive:true});}
