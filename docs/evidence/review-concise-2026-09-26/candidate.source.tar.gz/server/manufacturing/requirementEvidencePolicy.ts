import { isDeepStrictEqual } from "node:util";
import { createRequirementBrief, evaluateRequirementBrief, requiredRequirementFacts, optionalPackagingFacts, type RequirementBriefV1 } from "../../src/manufacturing/requirementBrief";
import type { EvidenceReviewPolicy } from "../enterprise/evidenceReviewWorkflow";

export const requirementEvidencePolicy: EvidenceReviewPolicy = {
	version: "packaging-requirement-evidence.v2.4",
	instructions: [
		"Review this packaging presales handoff once against every original customer requirement, including narrative constraints and clarification questions. Compare title, customerGoal, assumptions and facts. This is not production-readiness approval. Report distinct defects only: merge duplicate findings and use one short sentence per reason. Do not restate passing checks.",
		`Required fields: ${requiredRequirementFacts.print.join(", ")}. Optional fields: ${optionalPackagingFacts.join(", ")}. Record supplied optional values without verifying them. Preserve explicit undecided specifications as limitations. Correctly disclosed missing fields or unverified values awaiting confirmation are not defects. Questions must address actual gaps or conflicts; do not invent ambiguity, require absent optional fields, or reopen explicit dates/constraints. "Not yet designed" is a supplied artwork status. Internal IDs, price, final artwork, production feasibility and supplier qualifications are not prerequisites for this handoff when limitations are disclosed.`,
		"Never invent order parameters, evidence or certification. A model_output sourceType is extraction provenance: inspect its cited original source. Human confirmation verifies only that order field, never supplier certification. Raw source containers and stale artifacts are bookkeeping, not new confirmation gates. Metadata, unreadable scans and model summaries are not original textual proof. Keep verified facts unchanged; conflicting dimensions/units unresolved; new proposals pending until explicitly confirmed. Plan confirmation grants execution only, never delivery approval.",
		"For review issues, use exact evidence refs and JSON Pointers. Narrative omissions without a canonical fact field belong at /customerGoal or /assumptions, not /facts. Suggest revise only for omission/unsupported at /title, /customerGoal, /assumptions or an existing /assumptions/N. Fact problems, contradictions and insufficient evidence require request_input; scope changes require reconfirm_plan. Include suggestedAction for each issue. These suggestions grant no permissions.",
	],
	evaluate: evaluateRequirementBrief,
	canRevise: (issues) => issues.length > 0 && issues.every((issue) =>
		issue.suggestedAction === "revise" && ["omission", "unsupported"].includes(issue.kind) &&
		/^\/(title|customerGoal|assumptions(?:\/\d+)?)$/.test(issue.location)),
	revisionSchema: {
		type: "object", properties: {
			title: { type: "string", minLength: 1, maxLength: 500 },
			customerGoal: { type: "string", minLength: 1, maxLength: 8000 },
			assumptions: { type: "array", maxItems: 30, items: { type: "string", minLength: 1, maxLength: 2000 } },
		}, required: ["title", "customerGoal", "assumptions"], additionalProperties: false,
	},
	applyRevision(content, output, issues) {
		const patch = JSON.parse(output);
		if (!patch || Object.keys(patch).sort().join() !== "assumptions,customerGoal,title" ||
			typeof patch.title !== "string" || !patch.title.trim() || patch.title.length > 500 ||
			typeof patch.customerGoal !== "string" || !patch.customerGoal.trim() || patch.customerGoal.length > 8000 ||
			!Array.isArray(patch.assumptions) || patch.assumptions.length > 30 ||
			patch.assumptions.some((v: unknown) => typeof v !== "string" || !v.trim() || v.length > 2000)) throw new Error("revision_out_of_scope");
		const candidate = content as RequirementBriefV1;
		for (const field of ["title", "customerGoal", "assumptions"] as const) {
			if (isDeepStrictEqual(candidate[field], patch[field])) continue;
			if (issues.some((issue) => issue.location === `/${field}`)) continue;
			if (field !== "assumptions" || candidate.assumptions.length !== patch.assumptions.length || candidate.assumptions.some((value, index) => value !== patch.assumptions[index] && !issues.some((issue) => issue.location === `/assumptions/${index}`))) throw new Error("unrequested_revision");
		}
		const revised = createRequirementBrief({ ...candidate, ...patch });
		if (!evaluateRequirementBrief(revised).passed || !isDeepStrictEqual(revised.facts, candidate.facts)) throw new Error("invalid_revision");
		return revised;
	},
};
