import assert from "node:assert/strict";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";
import { join, resolve } from "node:path";
import { parseArgs } from "node:util";
import type { EvidenceReviewIssue } from "../src/enterprise/evidenceReview";
import { requirementEvidencePolicy } from "../server/manufacturing/requirementEvidencePolicy";
import { AnthropicMessagesClient } from "../server/anthropic/client";
import { AnthropicModelProvider } from "../server/runtime/anthropicModelProvider";
import { ModelSettings } from "../server/modelSettings";
import { atomicReport, onlyOutputLimitUnknowns } from "./requirementAutomaticRun";
import { boundedProvider, flashRates, pricedUsage, reservedUsd, unresolved, type Ledger } from "./requirementIntakeRun";
import { sha256 } from "./requirementIntake";
import { scoreReview, type ReviewCase } from "./evidenceReviewComparison";

export function routingPassed(issues: EvidenceReviewIssue[]) {
	return issues.every(issue => issue.kind === "scope_change" ? issue.suggestedAction === "reconfirm_plan"
		: issue.suggestedAction === "revise" ? requirementEvidencePolicy.canRevise([issue])
		: issue.suggestedAction === "request_input");
}

async function main() {
	const { values } = parseArgs({ options: { prepare: { type: "boolean" }, online: { type: "boolean" }, directory: { type: "string" } } });
	assert(values.directory && values.prepare !== values.online, "choose_prepare_or_online");
	const directory = resolve(values.directory), fixturePath = "eval/fixtures/evidence-review-boundary/cases.json";
	const suite = JSON.parse(readFileSync(fixturePath, "utf8")) as { cases: ReviewCase[] };
	const priorDirectory = "docs/evidence/review-output-2026-09-26";
	const budgetBytes = readFileSync(join(priorDirectory, "budget.json")), budget = JSON.parse(budgetBytes.toString());
	const priorBytes = gunzipSync(readFileSync(join(priorDirectory, "low.report.json.gz"))), prior = JSON.parse(priorBytes.toString());
	assert(budget.usdLimit === 20 && prior.usdLimit === 20 && prior.status === "stopped_unknown" && budget.reservedUsd === reservedUsd(prior), "prior_budget_mismatch");
	const quarantined = prior.calls.filter((c: { kind: string; response?: unknown; failedResponse?: unknown }) => c.kind === "generate" && !c.response && !c.failedResponse);
	assert(quarantined.length === 1 && quarantined[0].requestSha256 === "2f3757207ab15c2e46fe91901ca1d15fcfb11eb03954d926cb0f843891e62854" && quarantined[0].reservationUsd === 0.011235, "unknown_identity_changed");
	assert(suite.cases.length === 12 && suite.cases.every(c => c.id !== "received-limit-83"), "quarantined_input_must_be_excluded");
	const files = ["eval/evidenceReviewBoundary.ts", fixturePath, "eval/evidenceReviewComparison.ts", "eval/requirementIntakeRun.ts", "eval/requirementAutomaticRun.ts", "eval/requirementIntake.ts", "server/runtime/modelFailure.ts", "server/runtime/anthropicModelProvider.ts", "server/runtime/modelTelemetry.ts", "server/anthropic/client.ts", "server/anthropic/stream.ts", "server/modelSettings.ts", "server/manufacturing/requirementEvidencePolicy.ts", "src/manufacturing/requirementBrief.ts", "src/enterprise/evidenceReview.ts", "package.json", "package-lock.json"];
	const hashes = () => Object.fromEntries(files.map(path => [path, sha256(readFileSync(path))]));
	const attempts = [1, 2].flatMap(repeat => suite.cases.flatMap((input, index) => ((repeat + index) % 2 ? ["baseline", "candidate"] : ["candidate", "baseline"]).map(arm => ({ id: `boundary-${input.id}-${repeat}-${arm}`, caseId: input.id, repeat, arm }))));
	const addition = requirementEvidencePolicy.instructions.at(-1)!;
	assert(requirementEvidencePolicy.version === "packaging-requirement-evidence.v2.3" && addition.startsWith("Issue locations and actions"), "unexpected_candidate_policy");
	if (values.prepare) {
		mkdirSync(directory);
		atomicReport(join(directory, "plan.json"), { protocol: "review-boundary-comparison.v1", sourceHashes: hashes(), budgetSha256: sha256(budgetBytes), priorReportSha256: sha256(priorBytes), priorReservedUsd: budget.reservedUsd, retainedUnknown: quarantined[0], attempts, model: "deepseek-v4-flash", maxOutputTokens: 8192, usdLimit: 20, rates: flashRates,
			candidateAddition: addition, gate: "Complete all 48 calls; candidate passes all 16 controls and all routing checks; candidate valid output count >= baseline. Otherwise do not adopt this prompt. No reasoning change.",
			unknownPolicy: "Do not retry the quarantined input. Retain every previous reservation. A new transport or unclassified unknown stops this new trial; only received output_limit may end an independent review and continue.", semanticQuality: "NOT_EVALUATED beyond authored controls" });
		console.log(JSON.stringify({ mode: "prepared_no_network", attempts: attempts.length, reservedUsd: budget.reservedUsd })); return;
	}
	const planBytes = readFileSync(join(directory, "plan.json")), plan = JSON.parse(planBytes.toString());
	assert.deepEqual(plan.sourceHashes, hashes(), "frozen_source_changed"); assert.deepEqual(plan.attempts, attempts, "attempts_changed");
	assert.equal(plan.budgetSha256, sha256(budgetBytes)); assert.equal(plan.priorReportSha256, sha256(priorBytes));
	assert(!existsSync(join(directory, "report.json")), "new_report_required");
	writeFileSync(join(directory, "runner.lock"), `${process.pid}\n`, { flag: "wx" });
	const env = { ...process.env }; new ModelSettings(resolve(env.PACKX_SETTINGS_PATH ?? ".packx-settings.json"), env).apply(env);
	assert(env.ANTHROPIC_API_KEY && env.ANTHROPIC_BASE_URL?.replace(/\/$/, "") === "https://api.deepseek.com/anthropic", "official_provider_required");
	const upstream = new AnthropicModelProvider(new AnthropicMessagesClient({ baseUrl: env.ANTHROPIC_BASE_URL, apiKey: env.ANTHROPIC_API_KEY }), plan.model, 8192);
	const ledger: Ledger = { usdLimit: 20, priorReservedUsd: budget.reservedUsd, calls: [] }, results: unknown[] = [];
	let status = "running";
	const save = () => atomicReport(join(directory, "report.json"), { protocol: plan.protocol, planSha256: sha256(planBytes), priorReportSha256: sha256(priorBytes), status, ...ledger, reservedUsd: reservedUsd(ledger), knownUsageUsd: ledger.calls.reduce((sum, call) => sum + (call.response || call.failedResponse ? pricedUsage((call.response ?? call.failedResponse)!, flashRates) : 0), 0), results });
	save();
	try {
		for (const attempt of attempts) {
			assert.deepEqual(plan.sourceHashes, hashes(), "frozen_source_changed");
			const input = suite.cases.find(c => c.id === attempt.caseId)!, request = structuredClone(input.request);
			assert(request.tools.length === 0 && !request.reasoning && request.maxOutputTokens === 8192, "request_boundary_changed");
			if (attempt.arm === "candidate") {
				request.messages.find(m => m.role === "system")!.content += "\n" + addition;
				const body = JSON.parse(request.messages.at(-1)!.content); body.policyVersion = requirementEvidencePolicy.version;
				request.messages.at(-1)!.content = JSON.stringify(body);
			}
			assert(sha256(JSON.stringify(request)) !== quarantined[0].requestSha256, "quarantined_request_cannot_repeat");
			const local: Ledger = { usdLimit: 20, priorReservedUsd: reservedUsd(ledger), calls: [] }; let copied = 0;
			const provider = boundedProvider(upstream, local, attempt.id, () => "isolated-review-boundary", () => { ledger.calls.push(...local.calls.slice(copied)); copied = local.calls.length; save(); });
			const started = performance.now();
			try {
				const response = await provider.generate(request, AbortSignal.timeout(120_000)), score = scoreReview(input, response.text);
				results.push({ ...attempt, status: "valid", ...score, routingPassed: routingPassed(score.issues), canRevise: requirementEvidencePolicy.canRevise(score.issues), durationMs: Math.round(performance.now() - started) });
			} catch {
				results.push({ ...attempt, status: "failed", error: local.calls.at(-1)?.error ?? "invalid_review_or_local_failure", controlPassed: input.expected.kind === "protocol_only" ? null : false, routingPassed: false, durationMs: Math.round(performance.now() - started) });
			}
			save(); console.log(JSON.stringify(results.at(-1)));
			if (unresolved(local) && !onlyOutputLimitUnknowns(local.calls)) { status = "stopped_unknown"; break; }
			if (!local.calls.some(c => c.kind === "generate") || reservedUsd(ledger) >= 20) { status = "stopped_budget"; break; }
		}
		if (status === "running") status = "completed";
	} catch { status = "stopped_local_error"; }
	finally { save(); }
}
if (process.argv[1] && resolve(process.argv[1]) === resolve(import.meta.filename)) await main();
