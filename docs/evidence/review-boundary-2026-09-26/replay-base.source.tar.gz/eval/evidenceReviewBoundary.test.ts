import { readFileSync } from "node:fs";
import { expect, it } from "vitest";
import type { EvidenceReviewIssue } from "../src/enterprise/evidenceReview";
import { routingPassed } from "./evidenceReviewBoundary";
import { scoreReview, type ReviewCase } from "./evidenceReviewComparison";

it("measures action safety without correcting the model's path or granting revision authority", () => {
	const issue: EvidenceReviewIssue = { kind: "omission", location: "/facts", evidenceRefs: ["source"], reason: "missing narrative", suggestedAction: "revise" };
	expect(routingPassed([issue])).toBe(false); expect(issue.location).toBe("/facts");
	expect(routingPassed([{ ...issue, location: "/customerGoal" }])).toBe(true);
	expect(routingPassed([{ ...issue, suggestedAction: "request_input" }])).toBe(true);
	expect(routingPassed([{ ...issue, kind: "contradiction", location: "/customerGoal" }])).toBe(false);
	expect(routingPassed([{ ...issue, kind: "scope_change", suggestedAction: "reconfirm_plan" }])).toBe(true);
	expect(routingPassed([{ ...issue, kind: "scope_change", suggestedAction: "request_input" }])).toBe(false);
});

it("excludes the quarantined input and keeps new positive/negative sources aligned", () => {
	const suite = JSON.parse(readFileSync("eval/fixtures/evidence-review-boundary/cases.json", "utf8")) as { cases: ReviewCase[] };
	expect(suite.cases).toHaveLength(12); expect(suite.cases.map(c => c.id)).not.toContain("received-limit-83");
	expect(suite.cases.filter(c => c.expected.kind !== "protocol_only")).toHaveLength(8);
	for (const input of suite.cases.filter(c => c.id.startsWith("logo-"))) {
		const body = JSON.parse(input.request.messages.at(-1)!.content);
		const source = body.evidence.find((e: { ref: string }) => e.ref === `RB-${input.id}-S01`);
		expect(source.content.content).toContain("Logo 不得镜像");
		const container = body.evidence.find((e: { content: { key?: string } }) => e.content.key === "customer_brief");
		expect(JSON.parse(container.content.value).messages[0].content).toContain("Logo 不得镜像");
		expect(JSON.stringify(body.candidate).includes("Logo 不得镜像")).toBe(input.id === "logo-clean");
		expect(scoreReview(input, '{"issues":[]}').controlPassed).toBe(input.id === "logo-clean");
	}
});
