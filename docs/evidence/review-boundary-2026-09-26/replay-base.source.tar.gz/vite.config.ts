import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

export default defineConfig({
  plugins: [react()],
  test: {
    environment: "node",
    include: ["src/**/*.test.ts", "server/**/*.test.ts", "eval/**/*.test.ts", "src/**/*.test.tsx"],
  },
});
