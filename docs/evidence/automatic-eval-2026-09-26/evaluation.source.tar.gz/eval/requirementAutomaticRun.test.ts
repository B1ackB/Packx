import { expect, it } from "vitest";
import { loadAutomaticSuite } from "./requirementAutomatic";
import { attemptSummary, matrixPlan, matrixSummary, priceProfiles } from "./requirementAutomaticRun";
import { newIntakeResult } from "./requirementIntake";
import { boundedProvider, pricedUsage, reservedUsd, type Ledger } from "./requirementIntakeRun";

it("freezes 72 interleaved same-model attempts and 36 second-model attempts without duplicate identities", () => {
	const ids = loadAutomaticSuite().manifest.caseIds, plan = matrixPlan(ids);
	expect(plan).toHaveLength(108);
	expect(new Set(plan.map((a) => a.id)).size).toBe(108);
	expect(plan.slice(0, 72).every((a) => a.model === "deepseek-v4-flash")).toBe(true);
	expect(plan.slice(72).every((a) => a.model === "deepseek-v4-pro" && a.arm === "candidate")).toBe(true);
	for (const id of ids) for (const arm of ["baseline", "candidate"]) expect(plan.filter((a) => a.caseId === id && a.arm === arm && a.model === "deepseek-v4-flash")).toHaveLength(3);
	expect(plan[0].arm).not.toBe(plan[24].arm);
});

it("reports unstarted attempts, failures and unknown costs instead of silently reducing the denominator", () => {
	const suite = loadAutomaticSuite(), plan = matrixPlan(suite.manifest.caseIds), result = newIntakeResult(suite.cases[0]);
	result.status = "failed"; result.error = "model_failure";
	const summary = matrixSummary(plan, [attemptSummary(plan[0], result, [])]);
	expect(summary[0]).toMatchObject({ planned: 36, recorded: 1, notRecorded: 35, passed: 0, failed: 1, passRateStarted: 0, knownCostPerSuccessUsd: null });
	expect(summary[1]).toMatchObject({ planned: 36, recorded: 0, notRecorded: 36, passRateStarted: null });
});

it("reserves the actual model profile and preserves its uncertain cost without allowing another call", async () => {
	const ledger: Ledger = { usdLimit: 0.1, calls: [] }; let calls = 0;
	const bounded = boundedProvider({ async countTokens() { return 1000; }, async generate() { calls++; throw new Error("disconnected"); } }, ledger, "attempt", () => "event", () => {}, priceProfiles["deepseek-v4-pro"]);
	const request = { messages: [], tools: [], maxOutputTokens: 8192, fallbackOutput: "" };
	await expect(bounded.generate(request)).rejects.toThrow("disconnected");
	expect(reservedUsd(ledger)).toBeCloseTo((1000 * 1.32 + 8192 * 3.96) / 1e6);
	await expect(bounded.generate(request)).rejects.toThrow("unresolved_call_blocks_batch");
	expect(calls).toBe(1);
	expect(pricedUsage({ text: "", toolCalls: [], usage: { inputTokens: 1000, cachedInputTokens: 2000, outputTokens: 100, reasoningOutputTokens: 50 } }, priceProfiles["deepseek-v4-pro"])).toBeCloseTo(0.001804);
});
