from pathlib import Path
from collections import Counter
import json,hashlib,gzip,tarfile,io
repo=Path('/Users/black/Documents/VSCodeProject/SmallBlack')
root=Path('/private/tmp/packx-intake-baseline-v2-finish3-20260925')
initial=Path('/private/tmp/packx-intake-baseline-20260925')
output=repo/'docs/evidence/requirement-intake-2026-09-25'
output.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(root/'report.json').read_bytes();r=json.loads(raw)
m=json.loads(Path('/private/tmp/intake-metrics-v2.json').read_text())
assert m['caseVerdicts']=={'failed':12} and m['checks'].get('needs_review',0)==0
assert not (root/'runner.lock').exists()
assert all(c['status'] in ['completed','unknown'] for c in r['calls'])
assert set(r['caseIds'])==set(json.loads((repo/'eval/fixtures/requirement-intake-v1/manifest.json').read_text())['development'])
assert sha((initial/'report.json').read_bytes())==r['reviewedStop']['reportSha256']
assert r['reviewedStop']['reportSha256']=='b937cd530965060c11d54b46c37a2f5214c8c5e36c2631d4a265c07613cd5045'
for name,digest in r['sourceHashes'].items():assert sha((repo/name).read_bytes())==digest,name
with tarfile.open('/private/tmp/packx-intake-initial-code.tar.gz') as t:
 initial_report=json.loads((initial/'report.json').read_bytes())
 for name,digest in initial_report['sourceHashes'].items():assert sha(t.extractfile(name).read())==digest,name
chain=[]
for item in r['continuations']:
 parent_path=Path(item['sourceDirectory'])/'report.json'
 parent_bytes=parent_path.read_bytes();parent=json.loads(parent_bytes)
 assert sha(parent_bytes)==item['sourceReportSha256']
 assert r['calls'][:len(parent['calls'])]==parent['calls']
 assert all(c['caseId'] not in item['excludedCaseIds'] for c in r['calls'][len(parent['calls']):])
 for old in parent['results']:
  new=next(x for x in r['results'] if x['caseId']==old['caseId'])
  for p in old['checkpoints']:
   n=next(v for v in new['checkpoints'] if v['capture']['id']==p['capture']['id'])
   assert n['capture']==p['capture'] and n['captureSha256']==p['captureSha256']
 assert sha(Path('/private/tmp/intake_continue.mts').read_bytes())==item['driverSha256']
 chain.append(dict(sourceReportSha256=item['sourceReportSha256'],excludedCaseIds=item['excludedCaseIds'],callsPreserved=len(parent['calls']),capturesPreserved=sum(len(c['checkpoints']) for c in parent['results'])))
x=next(x for x in r['results'] if x['caseId']=='RI-10');point=x['checkpoints'][1];capture=point['capture']
fact=next(f for f in capture['brief']['facts'] if f['key']=='dimensions')
candidate=next(c for c in capture['candidates'] if 'runtime:'+c['executionId']==fact['sourceRef'])
matches=[f for f in candidate['candidate']['facts'] if f['key']==fact['key'] and f['value']==fact['value'] and f.get('unit')==fact.get('unit')]
assert len(matches)==1 and matches[0]['sourceRef']=='RI-10-S04'
assert candidate['sourceRefs'][matches[0]['sourceRef']]==['RI-10-S04']
erratum=dict(caseId='RI-10',checkpointId='clarified',captureSha256=point['captureSha256'],checkId='field:dimensions:source',recordedStatus='failed',auditFinding='false_negative_first_duplicate_candidate_only',currentFact=fact,matchingCandidate=matches[0],resolvedSourceIds=['RI-10-S04'],effect='The current value has persisted source evidence. The scorer and confirmation guard only inspect the first candidate of this key. The earlier dimension_conflict checkpoint independently fails, so the strict case verdict remains failed; the final confirmation checkpoint was not reached. No score or capture overwritten.')
checks=[k for x in r['results'] for p in x['checkpoints'] for k in p['checks']]
unknown=[{k:v for k,v in c.items() if k not in ['request','response']} for c in r['calls'] if c['status']=='unknown']
audit=dict(finalReportSha256=sha(raw),initialReportSha256=r['reviewedStop']['reportSha256'],codeFilesVerified=len(r['sourceHashes']),initialCodeFilesVerified=len(initial_report['sourceHashes']),sourceHashesVerified=True,inputManifestSha256=r['manifestSha256'],scoringProtocolSha256=r['scoringProtocolSha256'],parentChain=chain,sourceIdLeakFindings=m['sourceIdLeakFindings'],sourceLeakCheckScope='Exact source IDs from other cases or future events only; not a proof of general semantic isolation.',unknownCalls=unknown,priorUnknown=r['reviewedStop']['unknown'],allUnknownsRetained=True,allExcludedCaseCallsUnchanged=True,allExistingCapturesUnchanged=True,noStartedCalls=True,holdoutCaseIds=['RI-04','RI-08','RI-12','RI-16'],holdoutModelRuns=0,semanticReviewMethod='codex_assisted, case author, unblinded, uncalibrated',measurementErrata=[erratum],transitionPassed=dict(Counter(k['id'].split(':')[-1] for k in checks if k['id'].startswith('transition:') and k['status']=='passed')),tests=dict(command='npm exec vitest run eval/requirementIntakeFixtures.test.ts eval/requirementIntake.test.ts server/eval/m2RequirementWorkflow.test.ts server/enterprise/evidenceReviewWorkflow.test.ts',files=4,passed=63),typecheck=dict(command='npm exec tsc -- --noEmit -p tsconfig.server.json',exitCode=0))
m.update(model=r['model'],endpoint=r['endpoint'],commit=r['commit'],sourceSha256=r['sourceSha256'],manifestSha256=r['manifestSha256'],scoringProtocolSha256=r['scoringProtocolSha256'],finalReportSha256=sha(raw),usdLimit=r['usdLimit'],knownUsageIsEstimateNotInvoice=True,unknownReservationUsd=sum(c['reservationUsd'] for c in unknown)+sum(c['reservationUsd'] for c in r['reviewedStop']['unknown']),measurementErrata=[{k:v for k,v in erratum.items() if k not in ['currentFact','matchingCandidate']}],transitionPassed=audit['transitionPassed'],businessApprovalRequiredObserved=sum(k['id']=='business_approval' and k['expected']==True for k in checks),businessApprovalRequiredPassed=sum(k['id']=='business_approval' and k['expected']==True and k['status']=='passed' for k in checks),recordedToolNames=dict(Counter(e['tool'] for x in r['results'] for e in x['traceEvents'] if e['type']=='tool.completed')),limits=r['limits'],environment=r['environment'],holdoutModelRuns=0,sourceDataset='authored_synthetic',semanticReviewMethod=audit['semanticReviewMethod'])
for name,data in [('summary.json',m),('audit.json',audit)]:
 (output/name).write_text(json.dumps(data,ensure_ascii=False,indent='\t')+'\n')
(output/'baseline.report.json.gz').write_bytes(gzip.compress(raw,mtime=0))
with tarfile.open(output/'supporting-evidence.tar.gz','w:gz') as t:
 t.add(initial/'report.json',arcname='initial-v1/report.json')
 t.add('/private/tmp/packx-intake-initial-code.tar.gz',arcname='initial-v1/source.tar.gz')
 for i,item in enumerate(r['continuations']):t.add(Path(item['sourceDirectory'])/'report.json',arcname=f'v2-parent-{i}/report.json')
 for parent,label in [(initial,'initial-v1/state'),(root,'v2-final/state')]:
  for p in sorted(parent.glob('RI-*')):
   assert p.is_dir()
   t.add(p,arcname=f'{label}/{p.name}')
 for name in r['sourceHashes']:t.add(repo/name,arcname='v2-final/source/'+name)
 t.add(repo/'eval/fixtures/requirement-intake-v1',arcname='v2-final/source/eval/fixtures/requirement-intake-v1')
 for name in ['intake_continue.mts','intake_metrics.py','intake_archive.py','intake-reviews-v2.json']:
  t.add('/private/tmp/'+name,arcname='operator/'+name)
 with tarfile.open('/private/tmp/packx-intake-initial-code.tar.gz') as code:
  pass
# Inspect local artifacts for common credential literals without printing matching content.
patterns=['sk-'+chr(0), 'Bearer '+chr(0)]
import re
secret=re.compile(rb'(?:sk-[A-Za-z0-9_-]{24,}|Bearer\s+[A-Za-z0-9_-]{30,})')
scanned=0
for b in [raw,(initial/'report.json').read_bytes()]:
 assert not secret.search(b),'suspected credential literal in report';scanned+=1
with tarfile.open(output/'supporting-evidence.tar.gz') as t:
 for member in t.getmembers():
  if member.isfile() and not member.name.endswith('.gz'):
   b=t.extractfile(member).read();assert not secret.search(b),f'suspected credential literal: {member.name}';scanned+=1
files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in output.iterdir() if p.is_file() and p.name!='manifest.json'}
manifest=dict(dataset='requirement-intake.v1',protocol=r['protocol'],date='2026-09-25',files=files,finalReportUncompressedSha256=sha(raw),initialReportSha256=r['reviewedStop']['reportSha256'],initialSourceArchiveSha256=sha(Path('/private/tmp/packx-intake-initial-code.tar.gz').read_bytes()),commonCredentialLiteralScanFiles=scanned,notices=['All business data are authored synthetic fixtures.','Stored report/call/capture contents have not been rewritten.','Unknown calls remain unresolved and reserved.','The supporting archive includes executed source snapshots, immutable parent reports, persisted business state, semantic reviews and the one-off operator continuation driver.','The continuation driver contains historical RI-02 wording in its reason; excludedCaseIds and retainedUnknowns are the complete per-continuation records.','Code snapshot and fixture hashes, not the Git commit alone, identify this uncommitted evaluation.'])
(output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent='\t')+'\n')
print(json.dumps({'output':str(output),'files':files,'audit':{'verifiedCodeFiles':len(r['sourceHashes']),'parentReports':len(chain),'reviewRecords':len(r['reviews']),'unknowns':len(unknown)+len(r['reviewedStop']['unknown']),'credentialScanFiles':scanned}},ensure_ascii=False))
